package frontend.grammaticalAnalysis.grammatical;

public class StmtNode extends Node {

    public StmtNode(int line) {
        super(line);
    }
}
