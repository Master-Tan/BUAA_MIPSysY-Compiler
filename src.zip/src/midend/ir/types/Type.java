package midend.ir.types;

public abstract class Type {

    public abstract int getSize();

}
