package backend.operand;

public class MipsOperand {
}
