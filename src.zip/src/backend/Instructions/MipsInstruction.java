package backend.Instructions;

public abstract class MipsInstruction {

    // TODO 分配寄存器



}
