package backend.Instructions;

public class MIPSmove extends MipsInstruction {
}
